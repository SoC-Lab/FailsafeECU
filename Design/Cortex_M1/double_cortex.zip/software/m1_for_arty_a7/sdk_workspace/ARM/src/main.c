#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

// Xilinx specific headers
#include "xparameters.h"
#include "xgpio.h"

#include "m1_for_arty.h"        // Project specific header

/*******************************************************************/

int main (void){
	// GPIO LED
	int status_LED;
	XGpio myGpio_LED;
	long long output;
	output = 4294967295;

	status_LED = XGpio_Initialize(&myGpio_LED,XPAR_GPIO_0_DEVICE_ID);
	if (status_LED != XST_SUCCESS) {
		return XST_FAILURE;
	}

	XGpio_SetDataDirection(&myGpio_LED, 1,0x00); // all are outputs //Second Parameter is GPIO Channel
	XGpio_DiscreteWrite(&myGpio_LED, 1, 3); // void XGpio_DiscreteWrite(XGpio *InstancePtr, unsigned Channel, u32 Mask);


    while ( 1 )
    {


    }
}
